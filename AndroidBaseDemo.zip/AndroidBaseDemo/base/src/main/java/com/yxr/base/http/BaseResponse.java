package com.yxr.base.http;

/**
 * @author ciba
 * @description 网络请求结果基类
 * @date 2020/9/17
 */
public class BaseResponse {
}
