package com.yxr.base.inf;

import android.support.annotation.ColorRes;

public interface IBaseImmersion {
    boolean needImmersion();

    boolean statusBarDarkFont();

    @ColorRes
    int statusBarColor();

    boolean fitsSystemWindows();
}
