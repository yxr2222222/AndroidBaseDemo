package com.yxr.base.view;

/**
 * @author ciba
 * @description MVP中的View层
 * @date 2020/9/17
 */
public interface IBaseView {
}
